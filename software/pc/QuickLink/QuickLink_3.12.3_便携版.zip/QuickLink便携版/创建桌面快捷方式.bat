@echo off
set "batpath=%~dp0"
set "target=%batpath%bin\QuickLink3.exe"
set "desktop=%USERPROFILE%\Desktop"
set "lnk=%desktop%\QuickLink3.lnk"
powershell -command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%lnk%');$s.TargetPath='%target%';$s.WorkingDirectory='%~dp0bin';$s.Save()"

